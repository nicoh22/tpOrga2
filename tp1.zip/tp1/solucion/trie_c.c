#include "trie.h"
#include "listaP.h"

// Completar las funciones en C.

listaP *predecir_palabras(trie *t, char *teclas) {
	// COMPLETAR AQUI EL CODIGO
}

double peso_palabra(char *palabra) {
	// COMPLETAR AQUI EL CODIGO
}
