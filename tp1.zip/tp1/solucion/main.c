#include <stdio.h>
#include "trie.h"

int main(void) {
	// COMPLETAR AQUI EL CODIGO
    return 0;
}

